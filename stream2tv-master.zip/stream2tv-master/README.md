# stream2tv
Stream any local video file to any UPnP/DLNA MediaRenderer. Supports subtitles too.

## Installation
```
# npm install -g stream2tv
```
## Usage
```
$ stream2tv <a video file>
```
stream2tv will connect to the first available upnp device.
